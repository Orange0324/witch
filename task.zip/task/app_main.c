#include "app_main.h"
#include "FreeRTOS.h"
#include "task.h"
#include "bsp_oled.h"
#include "font.h"
#include "key_task.h"
#include "display_task.h"
#include "clock_task.h"
#include "sensor_task.h"
#include "alarm_task.h"
#include "led_task.h"
#include "ds1302.h"
#include "beep.h"

// 系统状态机
typedef enum {
    SYS_STATE_NORMAL = 0,
    SYS_STATE_TIME_SET,
    SYS_STATE_ALARM_SET
} SystemState_t;

static SystemState_t g_SystemState = SYS_STATE_NORMAL;

// 时间设置处理
static void Handle_TimeSetting(KeyEvent_t event)
{
    switch (event) {
        case KEY_EVENT_ALM_PRESS:
            g_SetNum++;
            if (g_SetNum > 4) g_SetNum = 0;
            break;
            
        case KEY_EVENT_ADD_PRESS:
            switch (g_SetNum) {
                case 0:
                    g_SetYear++;
                    if (g_SetYear > 59) g_SetYear = 0;
                    break;
                case 1:
                    g_SetMonth++;
                    if (g_SetMonth > 12) g_SetMonth = 1;
                    if (g_SetDay > Clock_GetMaxDaysInMonth(g_SetYear, g_SetMonth)) {
                        g_SetDay = Clock_GetMaxDaysInMonth(g_SetYear, g_SetMonth);
                    }
                    break;
                case 2:
                    g_SetDay++;
                    if (g_SetDay > Clock_GetMaxDaysInMonth(g_SetYear, g_SetMonth)) g_SetDay = 1;
                    break;
                case 3:
                    g_SetHour++;
                    if (g_SetHour > 23) g_SetHour = 0;
                    break;
                case 4:
                    g_SetMinute++;
                    if (g_SetMinute > 59) g_SetMinute = 0;
                    break;
            }
            break;
            
        case KEY_EVENT_DEC_PRESS:
            switch (g_SetNum) {
                case 0:
                    if (g_SetYear > 0) g_SetYear--;
                    else g_SetYear = 59;
                    break;
                case 1:
                    if (g_SetMonth > 1) g_SetMonth--;
                    else g_SetMonth = 12;
                    if (g_SetDay > Clock_GetMaxDaysInMonth(g_SetYear, g_SetMonth)) {
                        g_SetDay = Clock_GetMaxDaysInMonth(g_SetYear, g_SetMonth);
                    }
                    break;
                case 2:
                    if (g_SetDay > 1) g_SetDay--;
                    else g_SetDay = Clock_GetMaxDaysInMonth(g_SetYear, g_SetMonth);
                    break;
                case 3:
                    if (g_SetHour > 0) g_SetHour--;
                    else g_SetHour = 23;
                    break;
                case 4:
                    if (g_SetMinute > 0) g_SetMinute--;
                    else g_SetMinute = 59;
                    break;
            }
            break;
            
        case KEY_EVENT_ADJ_PRESS:
        case KEY_EVENT_ADJ_LONG_PRESS:
            // 保存时间设置
            {
                struct TIMEData newTime;
                newTime.year = g_SetYear + 2000;
                newTime.month = g_SetMonth;
                newTime.day = g_SetDay;
                newTime.hour = g_SetHour;
                newTime.minute = g_SetMinute;
                newTime.second = 0;
                newTime.week = Clock_CalculateWeekDay(g_SetYear, g_SetMonth, g_SetDay);
                Clock_SetTime(&newTime);
            }
            g_SystemState = SYS_STATE_NORMAL;
            g_DisplayMode = DISPLAY_MODE_NORMAL;
            break;
            
        default:
            break;
    }
}

// 闹钟设置处理
static void Handle_AlarmSetting(KeyEvent_t event)
{
    switch (event) {
        case KEY_EVENT_ALM_PRESS:
        case KEY_EVENT_ALM_LONG_PRESS:
            g_AlarmSetNum++;
            if (g_AlarmSetNum > 2) g_AlarmSetNum = 0;
            break;
            
        case KEY_EVENT_ADD_PRESS:
            switch (g_AlarmSetNum) {
                case 0:
                    g_AlarmHour++;
                    if (g_AlarmHour > 23) g_AlarmHour = 0;
                    break;
                case 1:
                    g_AlarmMinute++;
                    if (g_AlarmMinute > 59) g_AlarmMinute = 0;
                    break;
                case 2:
                    g_AlarmEnable = !g_AlarmEnable;
                    break;
            }
            break;
            
        case KEY_EVENT_DEC_PRESS:
            switch (g_AlarmSetNum) {
                case 0:
                    if (g_AlarmHour > 0) g_AlarmHour--;
                    else g_AlarmHour = 23;
                    break;
                case 1:
                    if (g_AlarmMinute > 0) g_AlarmMinute--;
                    else g_AlarmMinute = 59;
                    break;
                case 2:
                    g_AlarmEnable = !g_AlarmEnable;
                    break;
            }
            break;
            
        case KEY_EVENT_ADJ_PRESS:
        case KEY_EVENT_ADJ_LONG_PRESS:
            // 保存闹钟设置并退出
            Alarm_Hour = g_AlarmHour;
            Alarm_Minute = g_AlarmMinute;
            Alarm_Clock = g_AlarmEnable;
            g_SystemState = SYS_STATE_NORMAL;
            g_DisplayMode = DISPLAY_MODE_NORMAL;
            break;
            
        default:
            break;
    }
}

// 主控制任务
static void MainControl_Task(void *pvParameters)
{
    KeyEvent_t event;
    
    (void)pvParameters;
    
    while (1) {
        // 非阻塞方式接收按键事件，避免vTaskDelay依赖问题
        if (xQueueReceive(xKeyEventQueue, &event, 0) == pdPASS) {
            switch (g_SystemState) {
                case SYS_STATE_NORMAL:
                    if (event == KEY_EVENT_ADJ_LONG_PRESS) {
                        // 进入时间设置模式
                        struct TIMEData time;
                        Clock_GetTime(&time);
                        g_SetYear = time.year - 2000;
                        g_SetMonth = time.month;
                        g_SetDay = time.day;
                        g_SetHour = time.hour;
                        g_SetMinute = time.minute;
                        g_SetNum = 0;
                        g_SystemState = SYS_STATE_TIME_SET;
                        g_DisplayMode = DISPLAY_MODE_TIME_SET;
                    } else if (event == KEY_EVENT_ALM_LONG_PRESS) {
                        // 进入闹钟设置模式
                        g_AlarmHour = Alarm_Hour;
                        g_AlarmMinute = Alarm_Minute;
                        g_AlarmEnable = Alarm_Clock;
                        g_AlarmSetNum = 0;
                        g_SystemState = SYS_STATE_ALARM_SET;
                        g_DisplayMode = DISPLAY_MODE_ALARM_SET;
                    } else if (event == KEY_EVENT_DEC_STOP_ALARM) {
                        Alarm_Stop();
                    }
                    break;
                    
                case SYS_STATE_TIME_SET:
                    Handle_TimeSetting(event);
                    break;
                    
                case SYS_STATE_ALARM_SET:
                    Handle_AlarmSetting(event);
                    break;
            }
        }
        
        // 更新显示数据
        {
            struct TIMEData time;
            DisplayData_t displayData;
            
            Clock_GetTime(&time);
            
            displayData.year = time.year;
            displayData.month = time.month;
            displayData.day = time.day;
            displayData.hour = time.hour;
            displayData.minute = time.minute;
            displayData.second = time.second;
            displayData.week = time.week;
            displayData.temperature = 20;  // 默认值，实际温湿度在显示任务中读取
            displayData.humidity = 55;     // 默认值，实际温湿度在显示任务中读取
            
            Display_UpdateData(&displayData);
        }
        
        // 简单延时，让出CPU给其他任务
        for(uint32_t i = 0; i < 1000; i++) {
            __NOP();
        }
    }
}

// 简单的空循环延时函数，不依赖任何外设或中断
// STM32F103 @72MHz，使用8MHz外部晶振，实际测试调整
static void Simple_Delay_ms(uint32_t ms)
{
    volatile uint32_t i, j;
    for(i = 0; i < ms; i++)
    {
        for(j = 0; j < 200; j++)  // 约1ms @72MHz
        {
            __NOP(); __NOP(); __NOP(); __NOP();
            __NOP(); __NOP(); __NOP(); __NOP();
        }
    }
}

// 应用任务启动函数
void App_Tasks_Start(void)
{
    // 初始化外设
    OLED_Init();
    
    OLED_DrawBMP(0, 0, 128, 8, BMP19);
    
    Simple_Delay_ms(1000);
    OLED_Clear();
    
    // 先初始化显示数据，避免显示任务首次运行时数据为0
    {
        DisplayData_t initData = {
            .year = 2026,
            .month = 1,
            .day = 1,
            .hour = 0,
            .minute = 1,
            .second = 3,
            .week = 4,      // 星期四
            .temperature = 20,
            .humidity = 55
        };
        Display_UpdateData(&initData);
    }
    
    // 创建各个任务（减小栈大小以节省RAM）
    Key_Task_Create();
    Display_Task_Create();
    Clock_Task_Create();
    Sensor_Task_Create();
    Alarm_Task_Create();
    LED_Task_Create();
    
    // 创建主控制任务
    xTaskCreate(MainControl_Task, "MainCtrl", 256, NULL, 3, NULL);
    
    // 启动FreeRTOS调度器
    vTaskStartScheduler();
}
