#ifndef __KEY_H
#define __KEY_H

#include "main.h"

// �������� - ʹ�� CubeMX ���ɵĺ�
#define KEY_DEC_PORT    GPIOB
#define KEY_DEC_PIN     KEY_DEC_Pin

#define KEY_ADJ_PORT    GPIOB
#define KEY_ADJ_PIN     KEY_ADJ_Pin

#define KEY_ADD_PORT    GPIOB
#define KEY_ADD_PIN     KEY_ADD_Pin

#define KEY_ALM_PORT    GPIOB
#define KEY_ALM_PIN     KEY_ALM_Pin

// ��ȡ����״̬
#define KEY_DEC     HAL_GPIO_ReadPin(KEY_DEC_PORT, KEY_DEC_PIN)
#define KEY_ADJ     HAL_GPIO_ReadPin(KEY_ADJ_PORT, KEY_ADJ_PIN)
#define KEY_ADD     HAL_GPIO_ReadPin(KEY_ADD_PORT, KEY_ADD_PIN)
#define KEY_ALM     HAL_GPIO_ReadPin(KEY_ALM_PORT, KEY_ALM_PIN)

#endif
