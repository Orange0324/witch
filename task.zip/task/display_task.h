#ifndef __DISPLAY_TASK_H
#define __DISPLAY_TASK_H

#include "main.h"
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"

// 显示模式
typedef enum {
    DISPLAY_MODE_NORMAL = 0,    // 正常显示模式
    DISPLAY_MODE_TIME_SET,      // 时间设置模式
    DISPLAY_MODE_ALARM_SET,     // 闹钟设置模式
} DisplayMode_t;

// 显示数据共享结构体
typedef struct {
    uint16_t year;
    uint8_t month;
    uint8_t day;
    uint8_t hour;
    uint8_t minute;
    uint8_t second;
    uint8_t week;
    uint8_t temperature;
    uint8_t humidity;
} DisplayData_t;

// 全局显示数据
extern DisplayData_t g_DisplayData;
extern DisplayMode_t g_DisplayMode;
extern SemaphoreHandle_t xDisplayMutex;

// 时间设置相关变量（用于设置模式）
extern uint8_t g_SetYear, g_SetMonth, g_SetDay, g_SetHour, g_SetMinute;
extern uint8_t g_SetNum;  // 当前设置项

// 闹钟设置相关变量
extern uint8_t g_AlarmHour, g_AlarmMinute;
extern uint8_t g_AlarmEnable;
extern uint8_t g_AlarmSetNum;

// 显示任务创建函数
void Display_Task_Create(void);

// 初始化正常显示界面
void Display_Init_Normal(void);

// 更新显示数据接口
void Display_UpdateData(DisplayData_t *data);

#endif
