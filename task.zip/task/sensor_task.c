#include "sensor_task.h"
#include "dht11.h"
#include "stm32f1xx_hal.h"
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"

SensorData_t g_SensorData = {0};
static SemaphoreHandle_t xSensorMutex = NULL;  // 互斥锁句柄（动态分配）

// 获取传感器数据（线程安全）
void Sensor_GetData(SensorData_t *data)
{
    if (xSensorMutex != NULL && data != NULL) {
        // 获取互斥锁保护共享数据
        if (xSemaphoreTake(xSensorMutex, portMAX_DELAY) == pdTRUE) {
            *data = g_SensorData;
            xSemaphoreGive(xSensorMutex);
        }
    }
}

static void Sensor_Task(void *pvParameters)
{
    uint8_t temp, hum;
    
    (void)pvParameters;
    
    // 创建互斥锁保护传感器数据（动态内存分配）
    xSensorMutex = xSemaphoreCreateMutex();
    
    // 设置初始默认值（带临界区保护）
    if (xSensorMutex != NULL) {
        if (xSemaphoreTake(xSensorMutex, portMAX_DELAY) == pdTRUE) {
            g_SensorData.temperature = 20;
            g_SensorData.humidity = 55;
            xSemaphoreGive(xSensorMutex);
        }
    }
    
    // 必须先启动TIM4（DHT11_Read依赖mdelay/udelay，而它们依赖TIM4）
    extern TIM_HandleTypeDef htim4;
    HAL_TIM_Base_Start(&htim4);
    
    // 初始化DHT11
    DHT11_Init();
    
    while(1)
    {
        // 禁用中断保护DHT11时序（短时间临界区）
        taskENTER_CRITICAL();
        if (DHT11_Read(&hum, &temp) == 0)
        {
            // 使用互斥锁保护共享数据
            if (xSensorMutex != NULL) {
                if (xSemaphoreTake(xSensorMutex, 0) == pdTRUE) {
                    g_SensorData.temperature = temp;
                    g_SensorData.humidity = hum;
                    xSemaphoreGive(xSensorMutex);
                }
            }
        }
        taskEXIT_CRITICAL();
        
        // DHT11建议读取间隔至少2秒，避免频繁读取
        vTaskDelay(pdMS_TO_TICKS(2000));
    }
}

void Sensor_Task_Create(void)
{
    BaseType_t xReturn;
    
    xReturn = xTaskCreate(Sensor_Task, "SensorTask", 256, NULL, 3, NULL);
    if (xReturn != pdPASS) {
        // 任务创建失败处理
        while(1);
    }
}
