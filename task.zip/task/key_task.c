#include "key_task.h"
#include "key.h"
#include "beep.h"
#include "FreeRTOS.h"
#include "queue.h"

QueueHandle_t xKeyEventQueue = NULL;

// 按键消抖和状态检测
static uint8_t Key_Scan(uint8_t key_pin, uint8_t *key_state, uint16_t *key_count)
{
    uint8_t key_pressed = (key_pin == GPIO_PIN_RESET) ? 1 : 0;
    
    if (key_pressed) {
        (*key_count)++;
        if (*key_count == 3) {  // 30ms消抖
            *key_state = 1;
            return 1;  // 短按触发
        }
        if (*key_count == 100) {  // 1秒长按
            return 2;  // 长按触发
        }
    } else {
        *key_count = 0;
        *key_state = 0;
    }
    return 0;
}

static void Key_Task(void *pvParameters)
{
    uint16_t adj_count = 0, add_count = 0, dec_count = 0, alm_count = 0;
    uint8_t adj_state = 0, add_state = 0, dec_state = 0, alm_state = 0;
    KeyEvent_t event;
    
    (void)pvParameters;
    
    while (1) {
        // 扫描ADJ键
        uint8_t adj_result = Key_Scan(KEY_ADJ, &adj_state, &adj_count);
        if (adj_result == 2) {  // 长按进入时间设置
            event = KEY_EVENT_ADJ_LONG_PRESS;
            if(xKeyEventQueue) xQueueSend(xKeyEventQueue, &event, 0);
            adj_count = 0;
        }
        
        // 扫描ADD键
        uint8_t add_result = Key_Scan(KEY_ADD, &add_state, &add_count);
        if (add_result == 1) {
            event = KEY_EVENT_ADD_PRESS;
            if(xKeyEventQueue) xQueueSend(xKeyEventQueue, &event, 0);
        }
        
        // 扫描DEC键
        uint8_t dec_result = Key_Scan(KEY_DEC, &dec_state, &dec_count);
        if (dec_result == 1) {
            extern uint8_t Alarm_Clock_flag;
            if (Alarm_Clock_flag) {
                event = KEY_EVENT_DEC_STOP_ALARM;
            } else {
                event = KEY_EVENT_DEC_PRESS;
            }
            if(xKeyEventQueue) xQueueSend(xKeyEventQueue, &event, 0);
        }
        
        // 扫描ALM键
        uint8_t alm_result = Key_Scan(KEY_ALM, &alm_state, &alm_count);
        if (alm_result == 2) {  // 长按进入闹钟设置
            event = KEY_EVENT_ALM_LONG_PRESS;
            if(xKeyEventQueue) xQueueSend(xKeyEventQueue, &event, 0);
            alm_count = 0;
        } else if (alm_result == 1) {
            event = KEY_EVENT_ALM_PRESS;
            if(xKeyEventQueue) xQueueSend(xKeyEventQueue, &event, 0);
        }
        
        // 使用FreeRTOS标准延时，让出CPU给其他任务
        vTaskDelay(pdMS_TO_TICKS(10));
    }
}

void Key_Task_Create(void)
{
    xKeyEventQueue = xQueueCreate(10, sizeof(KeyEvent_t));
    if (xKeyEventQueue == NULL) {
        // 队列创建失败处理
        return;
    }
    
    xTaskCreate(Key_Task, "KeyTask", 256, NULL, 3, NULL);
}
