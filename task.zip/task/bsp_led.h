#ifndef __BSP_LED_H
#define __BSP_LED_H 

#include "main.h"

// STM32默认电平为低电平，驱动时应为高电平
#define RUN_Indicate_ENABLE            HAL_GPIO_WritePin(GPIOB, LED_RUN_Pin, GPIO_PIN_SET);     // 系统运行指示灯亮
#define RUN_Indicate_UNABLE            HAL_GPIO_WritePin(GPIOB, LED_RUN_Pin, GPIO_PIN_RESET);   // 系统运行指示灯灭

#define Limit_ENABLE                   HAL_GPIO_WritePin(GPIOA, LED_LIMIT_Pin, GPIO_PIN_RESET);   // 温湿度超限指示灯亮
#define Limit_UNABLE                   HAL_GPIO_WritePin(GPIOA, LED_LIMIT_Pin, GPIO_PIN_SET);     // 温湿度超限指示灯灭

#define Alarm_ENABLE                   HAL_GPIO_WritePin(GPIOA, LED_ALARM_Pin, GPIO_PIN_RESET);   // 闹钟指示灯亮
#define Alarm_UNABLE                   HAL_GPIO_WritePin(GPIOA, LED_ALARM_Pin, GPIO_PIN_SET);     // 闹钟指示灯灭

// LED GPIO配置函数
void LED_GPIO_Config(void);

#endif /*__BSP_LED_H */

