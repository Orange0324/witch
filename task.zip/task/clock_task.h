#ifndef __CLOCK_TASK_H
#define __CLOCK_TASK_H

#include "main.h"
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "ds1302.h"

extern SemaphoreHandle_t xTimeMutex;

// 时钟任务创建函数
void Clock_Task_Create(void);

// 获取当前时间（线程安全）
void Clock_GetTime(struct TIMEData *time);

// 设置时间（线程安全）
void Clock_SetTime(struct TIMEData *time);

// 计算星期
uint8_t Clock_CalculateWeekDay(uint8_t year, uint8_t month, uint8_t day);

// 获取月份最大天数
uint8_t Clock_GetMaxDaysInMonth(uint8_t year, uint8_t month);

// 判断闰年
uint8_t Clock_IsLeapYear(uint8_t year);

#endif
