#ifndef __KEY_TASK_H
#define __KEY_TASK_H

#include "main.h"
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

// 按键事件类型
typedef enum {
    KEY_EVENT_NONE = 0,
    KEY_EVENT_ADJ_PRESS,      // 调整键短按
    KEY_EVENT_ADJ_LONG_PRESS, // 调整键长按（进入设置模式）
    KEY_EVENT_ADD_PRESS,      // 加键
    KEY_EVENT_DEC_PRESS,      // 减键
    KEY_EVENT_ALM_PRESS,      // 闹钟键短按
    KEY_EVENT_ALM_LONG_PRESS, // 闹钟键长按（进入闹钟设置）
    KEY_EVENT_DEC_STOP_ALARM  // 减键停止闹钟
} KeyEvent_t;

// 按键事件队列句柄
extern QueueHandle_t xKeyEventQueue;

// 按键任务创建函数
void Key_Task_Create(void);

#endif
