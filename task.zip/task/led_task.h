#ifndef __LED_TASK_H
#define __LED_TASK_H

#include "main.h"
#include "FreeRTOS.h"
#include "task.h"

// LED运行指示灯任务创建函数
void LED_Task_Create(void);

#endif
