#include "led_task.h"
#include "beep.h"
#include "bsp_led.h"


static void LED_Task(void *pvParameters)
{
    uint16_t Run_Indicate_num = 0;    
    (void)pvParameters;
    
    while (1) {
        Run_Indicate_num++;
        if (Run_Indicate_num >= 100) {  // 1秒周期
            Run_Indicate_num = 0;
        }
        
        // 运行指示灯闪烁（亮500ms，灭500ms）
        if (Run_Indicate_num >= 50) {
            // 共阳接法：低电平点亮
            HAL_GPIO_WritePin(GPIOB, LED_RUN_Pin, GPIO_PIN_SET);
        } else {
            // 高电平熄灭
            HAL_GPIO_WritePin(GPIOB, LED_RUN_Pin, GPIO_PIN_RESET);
        }
        
        vTaskDelay(pdMS_TO_TICKS(10));  // 10ms周期
    }
}

void LED_Task_Create(void)
{
    xTaskCreate(LED_Task, "LEDTask", 128, NULL, 3, NULL);  // 提高优先级到3
}
