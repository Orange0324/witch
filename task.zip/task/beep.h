#ifndef __LED_BUZZER_H
#define __LED_BUZZER_H

#include "main.h"

// LED端口定义
#define LED_RUN_PORT    GPIOC
#define LED_RUN_PIN     LED_RUN_Pin

#define LED_LIMIT_PORT  GPIOA
#define LED_LIMIT_PIN   LED_LIMIT_Pin

#define LED_ALARM_PORT  GPIOA
#define LED_ALARM_PIN   LED_ALARM_Pin

// 蜂鸣器端口定义
#define BEEP_PORT       GPIOC
#define BEEP_PIN        BEEP_Pin

// LED控制宏定义（共阳接法：低电平点亮）
#define LED_RUN_ON()      HAL_GPIO_WritePin(LED_RUN_PORT, LED_RUN_PIN, GPIO_PIN_RESET)  // 运行指示灯亮
#define LED_RUN_OFF()     HAL_GPIO_WritePin(LED_RUN_PORT, LED_RUN_PIN, GPIO_PIN_SET)    // 运行指示灯灭

#define LED_LIMIT_ON()    HAL_GPIO_WritePin(LED_LIMIT_PORT, LED_LIMIT_PIN, GPIO_PIN_RESET)  // 超限指示灯亮
#define LED_LIMIT_OFF()   HAL_GPIO_WritePin(LED_LIMIT_PORT, LED_LIMIT_PIN, GPIO_PIN_SET)    // 超限指示灯灭

#define LED_ALARM_ON()    HAL_GPIO_WritePin(LED_ALARM_PORT, LED_ALARM_PIN, GPIO_PIN_RESET)  // 闹钟指示灯亮
#define LED_ALARM_OFF()   HAL_GPIO_WritePin(LED_ALARM_PORT, LED_ALARM_PIN, GPIO_PIN_SET)    // 闹钟指示灯灭

// 蜂鸣器控制宏定义
#define BEEP_ON()         HAL_GPIO_WritePin(BEEP_PORT, BEEP_PIN, GPIO_PIN_RESET)  // 蜂鸣器响
#define BEEP_OFF()        HAL_GPIO_WritePin(BEEP_PORT, BEEP_PIN, GPIO_PIN_SET)    // 蜂鸣器停

#endif
