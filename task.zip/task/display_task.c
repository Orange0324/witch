#include "display_task.h"
#include "bsp_oled.h"
#include "ds1302.h"
#include "font.h"
#include "key_task.h"
#include "clock_task.h"
#include "dht11.h"
#include <string.h>

DisplayData_t g_DisplayData = {0};
DisplayMode_t g_DisplayMode = DISPLAY_MODE_NORMAL;
SemaphoreHandle_t xDisplayMutex = NULL;

uint8_t g_SetYear = 20, g_SetMonth = 1, g_SetDay = 1, g_SetHour = 0, g_SetMinute = 0;
uint8_t g_SetNum = 0;
uint8_t g_AlarmHour = 0, g_AlarmMinute = 1;
uint8_t g_AlarmEnable = 1;
uint8_t g_AlarmSetNum = 0;

static uint8_t CalculateWeekDay(uint8_t year, uint8_t month, uint8_t day)
{
    uint8_t c, week;
    uint16_t full_year = year + 2000;
    
    if (month < 3) {
        month += 12;
        full_year--;
    }
    
    year = full_year % 100;
    c = full_year / 100;
    
    week = (year + year/4 + c/4 - 2*c + 26*(month+1)/10 + day - 1) % 7;
    if (week == 0) week = 7;
    
    return week;
}

static void Show_Modify_Data(uint8_t a)
{
    OLED_ShowChar(40, 0, ' ', 16);
    OLED_ShowChar(108, 0, ' ', 16);
    OLED_ShowChar(40, 3, ' ', 16);
    OLED_ShowChar(108, 3, ' ', 16);
    OLED_ShowChar(40, 6, ' ', 16);
    OLED_ShowChar(108, 6, ' ', 16);
    
    OLED_ShowNum(20, 0, g_SetYear, 2, 16);
    OLED_ShowNum(88, 0, g_SetMonth, 2, 16);
    OLED_ShowNum(20, 3, g_SetDay, 2, 16);
    OLED_ShowNum(88, 3, g_SetHour, 2, 16);
    OLED_ShowNum(20, 6, g_SetMinute, 2, 16);
    
    uint8_t temp_w = CalculateWeekDay(g_SetYear, g_SetMonth, g_SetDay);
    OLED_ShowNum(88, 6, temp_w, 2, 16);
    
    switch(a) {
        case 0: OLED_ShowChar(40, 0, '*', 16); break;
        case 1: OLED_ShowChar(108, 0, '*', 16); break;
        case 2: OLED_ShowChar(40, 3, '*', 16); break;
        case 3: OLED_ShowChar(108, 3, '*', 16); break;
        case 4: OLED_ShowChar(40, 6, '*', 16); break;
    }
}

static void Show_Modify_Alarm(uint8_t a)
{
    OLED_ShowChar(48, 6, ' ', 16);
    OLED_ShowChar(72, 6, ' ', 16);
    OLED_ShowChar(108, 6, ' ', 16);
    
    // 闹钟时间两位数显示（带前导0）
    OLED_ShowChar(44, 3, (g_AlarmHour / 10) + '0', 16);
    OLED_ShowChar(52, 3, (g_AlarmHour % 10) + '0', 16);
    OLED_ShowChar(68, 3, (g_AlarmMinute / 10) + '0', 16);
    OLED_ShowChar(76, 3, (g_AlarmMinute % 10) + '0', 16);
    
    if(g_AlarmEnable) OLED_ShowChinese(104, 3, 31);
    else OLED_ShowChinese(104, 3, 32);
    
    switch(a) {
        case 0: OLED_ShowChar(48, 6, '*', 16); break;
        case 1: OLED_ShowChar(72, 6, '*', 16); break;
        case 2: OLED_ShowChar(108, 6, '*', 16); break;
    }
}

//static void Normal_Display(void)
//{
//    DisplayData_t data;
//    
//    xSemaphoreTake(xDisplayMutex, portMAX_DELAY);
//    memcpy(&data, &g_DisplayData, sizeof(DisplayData_t));
//    xSemaphoreGive(xDisplayMutex);
//    
//    OLED_ShowChinese(112, 0, data.week + 13);
//    
//    OLED_ShowNum(94, 3, data.second, 2, 16);
//    if(data.second < 10) OLED_ShowString(94, 3, "0", 16);
//    
//    if(data.second == 0) {
//        OLED_ShowNum(0, 0, data.year, 4, 16);
//        OLED_ShowString(32, 0, "-", 16);
//        OLED_ShowNum(42, 0, data.month, 2, 16);
//        OLED_ShowString(58, 0, "-", 16);
//        OLED_ShowNum(68, 0, data.day, 2, 16);
//        
//        if(data.month < 10) OLED_ShowString(42, 0, "0", 16);
//        if(data.day < 10) OLED_ShowString(68, 0, "0", 16);
//        
//        OLED_ShowNum(34, 3, data.hour, 2, 16);
//        OLED_ShowString(54, 3, ":", 16);
//        OLED_ShowNum(64, 3, data.minute, 2, 16);
//        OLED_ShowString(84, 3, ":", 16);
//        
//        if(data.minute < 10) OLED_ShowString(64, 3, "0", 16);
//        if(data.hour < 10) OLED_ShowString(34, 3, "0", 16);
//    }
//    
//    OLED_ShowChinese(0, 6, 35);
//    OLED_ShowChinese(16, 6, 36);
//    OLED_ShowString(30, 6, ":", 16);
//    OLED_ShowNum(36, 6, data.temperature, 2, 16);
//    OLED_ShowChinese(54, 6, 39);
//    
//    OLED_ShowChinese(68, 6, 37);
//    OLED_ShowChinese(84, 6, 38);
//    OLED_ShowString(98, 6, ":", 16);
//    OLED_ShowNum(104, 6, data.humidity, 2, 16);
//    OLED_ShowString(120, 6, "%", 16);
//}

void Display_Init_Normal(void)
{
    // 注意：不在此处清屏，因为App_Tasks_Start中已经清屏
    // OLED_Clear();
    
    // 从传感器获取温湿度数据
    uint8_t temp, hum;
    if (DHT11_Read(&hum, &temp) != 0) {
        temp = 20;
        hum = 55;
    }
    
    OLED_ShowChinese(84,0,12);//星
	OLED_ShowChinese(98,0,13);//期
	OLED_ShowChinese(112,0,TimeData.week+13);
    
    OLED_ShowNum(0, 0, TimeData.year, 4, 16);
    OLED_ShowString(32, 0, "-", 16);
    OLED_ShowNum(42, 0, TimeData.month, 2, 16);
    OLED_ShowString(58, 0, "-", 16);
    OLED_ShowNum(68, 0, TimeData.day, 2, 16);
    
    OLED_ShowString(42, 0, "0", 16);
    OLED_ShowString(68, 0, "0", 16);
    
    OLED_ShowNum(34, 3, TimeData.hour, 2, 16);
    OLED_ShowString(54, 3, ":", 16);
    OLED_ShowNum(64, 3, TimeData.minute, 2, 16);
    OLED_ShowString(84, 3, ":", 16);
    OLED_ShowNum(94, 3, TimeData.second, 2, 16);
    
    OLED_ShowString(64, 3, "0", 16);
    OLED_ShowString(94, 3, "0", 16);
    OLED_ShowString(34, 3, "0", 16);
    
    OLED_ShowChinese(0, 6, 35);
    OLED_ShowChinese(16, 6, 36);
    OLED_ShowString(30, 6, ":", 16);
    OLED_ShowNum(36, 6, temp, 2, 16);
    OLED_ShowChinese(54, 6, 39);
    
    OLED_ShowChinese(68, 6, 37);
    OLED_ShowChinese(84, 6, 38);
    OLED_ShowString(98, 6, ":", 16);
    OLED_ShowNum(104, 6, hum, 2, 16);
    OLED_ShowString(120, 6, "%", 16);
}

//// 简单的空循环延时函数（用于任务内）
//static void Task_Delay_ms(uint32_t ms)
//{
//    volatile uint32_t i, j;
//    for(i = 0; i < ms; i++)
//    {
//        for(j = 0; j < 200; j++)
//        {
//            __NOP(); __NOP(); __NOP(); __NOP();
//            __NOP(); __NOP(); __NOP(); __NOP();
//        }
//    }
//}

static void Display_Task(void *pvParameters)
{
    (void)pvParameters;
    
    // 先启动TIM4（DHT11_Read依赖mdelay/udelay，而它们依赖TIM4）
    extern TIM_HandleTypeDef htim4;
    // 停止中断模式，重新启动轮询模式
    HAL_TIM_Base_Stop_IT(&htim4);
    HAL_TIM_Base_Start(&htim4);
    
    // 先读取一次DS1302时间，确保TimeData有值
    DS1302_ReadRealTime();
    
    // 初始化OLED（如果还未初始化）
    OLED_Init();
    
    // 清屏
    OLED_Clear();
    
    // 初始化显示（两位数格式）
    OLED_ShowChinese(84, 0, 12);  // 星
    OLED_ShowChinese(98, 0, 13);  // 期
    OLED_ShowChinese(112, 0, TimeData.week + 13);
    
    // 日期显示（两位数格式，带前导0）
    OLED_ShowNum(0, 0, TimeData.year, 4, 16);
    OLED_ShowString(32, 0, "-", 16);
    OLED_ShowChar(42, 0, (TimeData.month / 10) + '0', 16);
    OLED_ShowChar(50, 0, (TimeData.month % 10) + '0', 16);
    OLED_ShowString(58, 0, "-", 16);
    OLED_ShowChar(68, 0, (TimeData.day / 10) + '0', 16);
    OLED_ShowChar(76, 0, (TimeData.day % 10) + '0', 16);
    
    // 时间显示（两位数格式，带前导0）
    OLED_ShowChar(34, 3, (TimeData.hour / 10) + '0', 16);
    OLED_ShowChar(42, 3, (TimeData.hour % 10) + '0', 16);
    OLED_ShowString(54, 3, ":", 16);
    OLED_ShowChar(64, 3, (TimeData.minute / 10) + '0', 16);
    OLED_ShowChar(72, 3, (TimeData.minute % 10) + '0', 16);
    OLED_ShowString(84, 3, ":", 16);
    OLED_ShowChar(94, 3, (TimeData.second / 10) + '0', 16);
    OLED_ShowChar(102, 3, (TimeData.second % 10) + '0', 16);
    
    OLED_ShowChinese(0, 6, 35);  // 温
    OLED_ShowChinese(16, 6, 36); // 度
    OLED_ShowString(30, 6, ":", 16);
    OLED_ShowChinese(54, 6, 39); // 度符号
    
    OLED_ShowChinese(68, 6, 37); // 湿
    OLED_ShowChinese(84, 6, 38); // 度
    OLED_ShowString(98, 6, ":", 16);
    OLED_ShowString(120, 6, "%", 16);
    
    DisplayMode_t lastMode = DISPLAY_MODE_NORMAL;
    
    while (1) {
        // 检测模式切换，切换时清屏
        if (g_DisplayMode != lastMode) {
            OLED_Clear();
            lastMode = g_DisplayMode;
            
            if (g_DisplayMode == DISPLAY_MODE_TIME_SET) {
                // 显示设置界面标题
                OLED_ShowChinese(0, 0, 21);
                OLED_ShowChinese(68, 0, 22);
                OLED_ShowChinese(0, 3, 23);
                OLED_ShowChinese(68, 3, 24);
                OLED_ShowChinese(0, 6, 25);
                OLED_ShowChinese(68, 6, 26);
            } else if (g_DisplayMode == DISPLAY_MODE_ALARM_SET) {
                // 显示闹钟设置界面标题
                OLED_ShowChinese(32, 0, 27);
                OLED_ShowChinese(48, 0, 28);
                OLED_ShowChinese(64, 0, 29);
                OLED_ShowChinese(80, 0, 30);
                OLED_ShowChar(60, 3, ':', 16);
            }
        }
        
        // 根据显示模式更新界面
        if (g_DisplayMode == DISPLAY_MODE_NORMAL) {
            // 读取DS1302实时时间
            DS1302_ReadRealTime();
            
            // 直接读取DHT11数据（禁用中断保护时序）
            uint8_t temp = 20, hum = 55;
            DHT11_Init();
            __disable_irq();
            int dht11_ret = DHT11_Read(&hum, &temp);
            __enable_irq();
            if (dht11_ret != 0) {
                temp = 20;
                hum = 55;
            }
            
            // 更新日期显示
            OLED_ShowNum(0, 0, TimeData.year, 4, 16);
            OLED_ShowString(32, 0, "-", 16);
            // 月份两位数显示（带前导0）
            OLED_ShowChar(42, 0, (TimeData.month / 10) + '0', 16);
            OLED_ShowChar(50, 0, (TimeData.month % 10) + '0', 16);
            OLED_ShowString(58, 0, "-", 16);
            // 日期两位数显示（带前导0）
            OLED_ShowChar(68, 0, (TimeData.day / 10) + '0', 16);
            OLED_ShowChar(76, 0, (TimeData.day % 10) + '0', 16);
            
            // 更新星期显示
            OLED_ShowChinese(84, 0, 12);  // 星
            OLED_ShowChinese(98, 0, 13);  // 期
            OLED_ShowChinese(112, 0, TimeData.week + 13);
            
            // 更新时间显示（两位数格式，带前导0）
            OLED_ShowChar(34, 3, (TimeData.hour / 10) + '0', 16);
            OLED_ShowChar(42, 3, (TimeData.hour % 10) + '0', 16);
            OLED_ShowString(54, 3, ":", 16);
            OLED_ShowChar(64, 3, (TimeData.minute / 10) + '0', 16);
            OLED_ShowChar(72, 3, (TimeData.minute % 10) + '0', 16);
            OLED_ShowString(84, 3, ":", 16);
            OLED_ShowChar(94, 3, (TimeData.second / 10) + '0', 16);
            OLED_ShowChar(102, 3, (TimeData.second % 10) + '0', 16);
            
            // 温湿度标签和数值
            OLED_ShowChinese(0, 6, 35);  // 温
            OLED_ShowChinese(16, 6, 36); // 度
            OLED_ShowString(30, 6, ":", 16);
            OLED_ShowNum(36, 6, temp, 2, 16);
            OLED_ShowChinese(54, 6, 39); // 度符号
            
            OLED_ShowChinese(68, 6, 37); // 湿
            OLED_ShowChinese(84, 6, 38); // 度
            OLED_ShowString(98, 6, ":", 16);
            OLED_ShowNum(104, 6, hum, 2, 16);
            OLED_ShowString(120, 6, "%", 16);
        }
        else if (g_DisplayMode == DISPLAY_MODE_TIME_SET) {
            Show_Modify_Data(g_SetNum);
        }
        else if (g_DisplayMode == DISPLAY_MODE_ALARM_SET) {
            Show_Modify_Alarm(g_AlarmSetNum);
        }
        
        // 简短延时
        for(uint32_t i = 0; i < 50000; i++) {
            __NOP();
        }
    }
}

void Display_Task_Create(void)
{
    xDisplayMutex = xSemaphoreCreateMutex();
    if (xDisplayMutex == NULL) {
        return;
    }
    
    // 设置适中优先级（3），让按键任务有机会运行
    xTaskCreate(Display_Task, "DisplayTask", 256, NULL, 3, NULL);
}

void Display_UpdateData(DisplayData_t *data)
{
    if (xDisplayMutex != NULL) {
        xSemaphoreTake(xDisplayMutex, portMAX_DELAY);
        memcpy(&g_DisplayData, data, sizeof(DisplayData_t));
        xSemaphoreGive(xDisplayMutex);
    }
}
