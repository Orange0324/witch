#ifndef __APP_MAIN_H
#define __APP_MAIN_H

#include "main.h"

// 应用层任务统一启动函数
void App_Tasks_Start(void);

#endif
