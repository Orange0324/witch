#include "clock_task.h"
#include <string.h>

SemaphoreHandle_t xTimeMutex = NULL;

uint8_t Clock_IsLeapYear(uint8_t year)
{
    uint16_t full_year = year + 2000;
    if ((full_year % 4 == 0 && full_year % 100 != 0) || (full_year % 400 == 0)) {
        return 1;
    }
    return 0;
}

uint8_t Clock_GetMaxDaysInMonth(uint8_t year, uint8_t month)
{
    switch(month) {
        case 1: case 3: case 5: case 7: case 8: case 10: case 12:
            return 31;
        case 4: case 6: case 9: case 11:
            return 30;
        case 2:
            return Clock_IsLeapYear(year) ? 29 : 28;
        default:
            return 31;
    }
}

uint8_t Clock_CalculateWeekDay(uint8_t year, uint8_t month, uint8_t day)
{
    uint8_t c, week;
    uint16_t full_year = year + 2000;
    
    if (month < 3) {
        month += 12;
        full_year--;
    }
    
    year = full_year % 100;
    c = full_year / 100;
    
    week = (year + year/4 + c/4 - 2*c + 26*(month+1)/10 + day - 1) % 7;
    if (week == 0) week = 7;
    
    return week;
}

void Clock_GetTime(struct TIMEData *time)
{
    if (xTimeMutex != NULL) {
        xSemaphoreTake(xTimeMutex, portMAX_DELAY);
        memcpy(time, &TimeData, sizeof(struct TIMEData));
        xSemaphoreGive(xTimeMutex);
    }
}

void Clock_SetTime(struct TIMEData *time)
{
    if (xTimeMutex != NULL) {
        xSemaphoreTake(xTimeMutex, portMAX_DELAY);
        memcpy(&TimeData, time, sizeof(struct TIMEData));
        
        // 写入DS1302
        DS1302_WriteTime();
        
        xSemaphoreGive(xTimeMutex);
    }
}

static void Clock_Task(void *pvParameters)
{
    static uint8_t last_day = 0;
    
    (void)pvParameters;
    
    // 初始化DS1302
    DS1302_Init();
    DS1302_ReadRealTime();
    
    while (1) {
        // 读取DS1302时间
        DS1302_ReadRealTime();
        
        // 检查日期变化，更新星期
        if (TimeData.day != last_day) {
            TimeData.week = Clock_CalculateWeekDay(TimeData.year - 2000, TimeData.month, TimeData.day);
            last_day = TimeData.day;
        }
        
        vTaskDelay(pdMS_TO_TICKS(500));  // 500ms读取一次
    }
}

void Clock_Task_Create(void)
{
    xTimeMutex = xSemaphoreCreateMutex();
    if (xTimeMutex == NULL) {
        return;
    }
    
    xTaskCreate(Clock_Task, "ClockTask", 256, NULL, 4, NULL);
}
