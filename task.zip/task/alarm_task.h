#ifndef __ALARM_TASK_H
#define __ALARM_TASK_H

#include "main.h"
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"

// 报警状态
extern uint8_t Alarm_Clock_flag;
extern uint8_t Alarm_Manual_Stop_flag;
extern uint8_t Over_Limit_flag;

// 报警设置
extern uint8_t Alarm_Hour;
extern uint8_t Alarm_Minute;
extern uint8_t Alarm_Clock;

// 报警任务创建函数
void Alarm_Task_Create(void);

// 停止闹钟
void Alarm_Stop(void);

// 手动停止标志清除（分钟变化时调用）
void Alarm_ClearManualStop(void);

#endif
