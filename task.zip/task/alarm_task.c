#include "alarm_task.h"
#include "beep.h"
#include "clock_task.h"
#include "sensor_task.h"

uint8_t Alarm_Clock_flag = 0;
uint8_t Alarm_Manual_Stop_flag = 0;
uint8_t Over_Limit_flag = 0;

uint8_t Alarm_Hour = 0;
uint8_t Alarm_Minute = 1;
uint8_t Alarm_Clock = 1;

static uint16_t Alarm_Clock_num = 0;
static uint16_t Over_Limit_Alarm_num = 0;

void Alarm_Stop(void)
{
    Alarm_Manual_Stop_flag = 1;
    Alarm_Clock_flag = 0;
    Alarm_Clock_num = 0;
    BEEP_OFF();
    LED_ALARM_OFF();
}

void Alarm_ClearManualStop(void)
{
    Alarm_Manual_Stop_flag = 0;
}

static void Alarm_Task(void *pvParameters)
{
    struct TIMEData time;
    SensorData_t sensor;
    uint8_t last_minute = 0xFF;
    
    (void)pvParameters;
    
    while (1) {
        // 获取当前时间
        Clock_GetTime(&time);
        
        // 检查闹钟
        if (Alarm_Clock && !Alarm_Manual_Stop_flag) {
            if ((time.hour == Alarm_Hour) && (time.minute == Alarm_Minute)) {
                Alarm_Clock_flag = 1;
            } else {
                Alarm_Clock_flag = 0;
            }
        } else {
            Alarm_Clock_flag = 0;
        }
        
        // 分钟变化时清除手动停止标志
        if (time.minute != last_minute) {
            Alarm_Manual_Stop_flag = 0;
            last_minute = time.minute;
        }
        
        // 闹钟响铃处理（间歇蜂鸣器）
        if (Alarm_Clock_flag) {
            Alarm_Clock_num++;
            if (Alarm_Clock_num >= 300) Alarm_Clock_num = 0;
            
            if ((Alarm_Clock_num <= 10) || 
                (Alarm_Clock_num >= 30 && Alarm_Clock_num <= 40) ||
                (Alarm_Clock_num >= 60 && Alarm_Clock_num <= 70) ||
                (Alarm_Clock_num >= 90 && Alarm_Clock_num <= 100)) {
                BEEP_ON();
                LED_ALARM_ON();
            } else {
                BEEP_OFF();
                LED_ALARM_OFF();
            }
        } else {
            Alarm_Clock_num = 0;
            LED_ALARM_OFF();
        }
        
        // 获取传感器数据检查超限
        Sensor_GetData(&sensor);
        
        // 温湿度超限判断（立即响应，无需延时）
        // 温度范围：15-30°C，湿度范围：30-60%
        if (sensor.temperature >= 30 || sensor.temperature <= 15 || 
            sensor.humidity >= 60 || sensor.humidity <= 30) {
            Over_Limit_flag = 1;
        } else {
            Over_Limit_flag = 0;
        }
        
        // 超限报警LED闪烁
        if (Over_Limit_flag) {
            Over_Limit_Alarm_num++;
            if (Over_Limit_Alarm_num >= 300) Over_Limit_Alarm_num = 0;
            
            if ((Over_Limit_Alarm_num <= 10) ||
                (Over_Limit_Alarm_num >= 30 && Over_Limit_Alarm_num <= 40) ||
                (Over_Limit_Alarm_num >= 60 && Over_Limit_Alarm_num <= 70)) {
                LED_LIMIT_ON();
            } else {
                LED_LIMIT_OFF();
            }
        } else {
            Over_Limit_Alarm_num = 0;
            LED_LIMIT_OFF();
        }
        
        // 无报警时关闭蜂鸣器
        if (!Alarm_Clock_flag && !Over_Limit_flag) {
            BEEP_OFF();
        }
        
        vTaskDelay(pdMS_TO_TICKS(10));  // 10ms周期
    }
}

void Alarm_Task_Create(void)
{
    xTaskCreate(Alarm_Task, "AlarmTask", 256, NULL, 3, NULL);
}
