#include "ds1302.h"
#include "bsp_oled.h"

struct TIMEData TimeData;
uint8_t time_buf[8] = {0};

// 微秒延时（简单实现）
static void DS1302_Delay_us(uint32_t us)
{
    uint32_t i;
    for(i = 0; i < us * 8; i++);  // 72MHz 下大约 8 个时钟周期 1us
}

// 设置 DATA 引脚为输出
static void DS1302_DATA_Out(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    GPIO_InitStruct.Pin = DS1302_DATA_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(DS1302_DATA_PORT, &GPIO_InitStruct);
}

// 设置 DATA 引脚为输入
static void DS1302_DATA_In(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    GPIO_InitStruct.Pin = DS1302_DATA_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(DS1302_DATA_PORT, &GPIO_InitStruct);
}

// 向 DS1302 写一个字节
static void DS1302_WriteByte(uint8_t data)
{
    uint8_t i;
    DS1302_DATA_Out();
    for(i = 0; i < 8; i++)
    {
        SCLK_L();
        DS1302_Delay_us(1);
        if(data & 0x01)
            DATA_H();
        else
            DATA_L();
        DS1302_Delay_us(1);
        SCLK_H();
        DS1302_Delay_us(1);
        data >>= 1;
    }
    SCLK_L();
}

// 从 DS1302 读一个字节（burst read 用）
static uint8_t DS1302_ReadByte(void)
{
    uint8_t i, data = 0;
    DS1302_DATA_In();
    for(i = 0; i < 8; i++)
    {
        SCLK_L();
        DS1302_Delay_us(2);
        data >>= 1;
        if(DATA_READ() == GPIO_PIN_SET)
            data |= 0x80;
        SCLK_H();
        DS1302_Delay_us(1);
    }
    SCLK_L();
    return data;
}

// 向寄存器写数据
static void DS1302_WriteReg(uint8_t addr, uint8_t data)
{
    CE_L();
    SCLK_L();
    DS1302_Delay_us(2);
    CE_H();
    DS1302_Delay_us(2);
    DS1302_WriteByte(addr);
    DS1302_WriteByte(data);
    SCLK_L();
    CE_L();
    DS1302_Delay_us(2);
}

// 从寄存器读数据
static uint8_t DS1302_ReadReg(uint8_t addr)
{
    uint8_t i, data = 0;
    
    CE_L();
    SCLK_L();
    DS1302_Delay_us(2);
    CE_H();
    DS1302_Delay_us(2);
    
    // 发送读地址（命令字节）
    DS1302_DATA_Out();
    for(i = 0; i < 8; i++)
    {
        SCLK_L();
        DS1302_Delay_us(1);
        if(addr & 0x01)
            DATA_H();
        else
            DATA_L();
        DS1302_Delay_us(1);
        SCLK_H();
        DS1302_Delay_us(1);
        addr >>= 1;
    }
    
    // 第8个时钟下降沿后，DS1302开始输出数据
    // 切换到输入模式
    DS1302_DATA_In();
    
    // 读取8个数据位
    for(i = 0; i < 8; i++)
    {
        SCLK_L();
        DS1302_Delay_us(2);
        data >>= 1;
        if(DATA_READ() == GPIO_PIN_SET)
            data |= 0x80;
        SCLK_H();
        DS1302_Delay_us(1);
    }
    
    SCLK_L();
    CE_L();
    DS1302_Delay_us(2);
    return data;
}

// 初始化 DS1302
void DS1302_Init(void)
{
    // 确保 GPIO 已初始化，设置初始状态
    CE_L();
    SCLK_L();
    DATA_L();
    DS1302_Delay_us(10);
    
    // 关闭写保护
    DS1302_WriteReg(0x8E, 0x00);
    
    // 设置初始时间（2026年1月1日 00:00:00 星期一）
    // 注意：DS1302 使用 BCD 编码
    DS1302_WriteReg(0x80, 0x00); // 秒: 00, CH=0 时钟运行
    DS1302_WriteReg(0x82, 0x00); // 分: 00
    DS1302_WriteReg(0x84, 0x00); // 时: 00 (24小时制)
    DS1302_WriteReg(0x86, 0x01); // 日: 01
    DS1302_WriteReg(0x88, 0x01); // 月: 01
    DS1302_WriteReg(0x8A, 0x04); // 星期: 星期一
    DS1302_WriteReg(0x8C, 0x26); // 年: 2026
    
    // 开启写保护
    DS1302_WriteReg(0x8E, 0x80);
}

// BCD 转十进制
static uint8_t BCDToDec(uint8_t bcd)
{
    return ((bcd >> 4) * 10) + (bcd & 0x0F);
}

// 十进制转 BCD
static uint8_t DecToBCD(uint8_t dec)
{
    return ((dec / 10) << 4) | (dec % 10);
}

// 读取时间
void DS1302_ReadTime(void)
{
    time_buf[0] = DS1302_ReadReg(0x81); // 秒
    time_buf[1] = DS1302_ReadReg(0x83); // 分
    time_buf[2] = DS1302_ReadReg(0x85); // 时
    time_buf[3] = DS1302_ReadReg(0x87); // 日
    time_buf[4] = DS1302_ReadReg(0x89); // 月
    time_buf[5] = DS1302_ReadReg(0x8B); // 星期
    time_buf[6] = DS1302_ReadReg(0x8D); // 年
}

// 读取并转换实时时间
void DS1302_ReadRealTime(void)
{
    DS1302_ReadTime();
    TimeData.second = BCDToDec(time_buf[0] & 0x7F);  // 去掉 CH 位
    TimeData.minute = BCDToDec(time_buf[1]);
    TimeData.hour   = BCDToDec(time_buf[2] & 0x3F);  // 去掉 12/24 小时位
    TimeData.day    = BCDToDec(time_buf[3]);
    TimeData.month  = BCDToDec(time_buf[4]);
    TimeData.week   = BCDToDec(time_buf[5]);
    TimeData.year   = BCDToDec(time_buf[6]) + 2000;
}

// 写入时间
void DS1302_WriteTime(void)
{
    DS1302_WriteReg(0x8E, 0x00); // 关闭写保护
    
    DS1302_WriteReg(0x80, DecToBCD(TimeData.second));
    DS1302_WriteReg(0x82, DecToBCD(TimeData.minute));
    DS1302_WriteReg(0x84, DecToBCD(TimeData.hour));
    DS1302_WriteReg(0x86, DecToBCD(TimeData.day));
    DS1302_WriteReg(0x88, DecToBCD(TimeData.month));
    DS1302_WriteReg(0x8A, DecToBCD(TimeData.week));
    DS1302_WriteReg(0x8C, DecToBCD(TimeData.year - 2000));
    
    DS1302_WriteReg(0x8E, 0x80); // 开启写保护
}

void RealTime_Display_Init(void)
{
    OLED_ShowChinese(84,0,12);
    OLED_ShowChinese(98,0,13);
    OLED_ShowChinese(112,0,TimeData.week+13);

    OLED_ShowNum(0,0,TimeData.year,4,16);
    OLED_ShowString(32,0,"-",16);
    OLED_ShowNum(42,0,TimeData.month,2,16);
    OLED_ShowString(58,0,"-",16);
    OLED_ShowNum(68,0,TimeData.day,2,16);
    if(TimeData.month<10)
    {
        OLED_ShowString(42,0,"0",16);
    }
    if(TimeData.day<10)
    {
        OLED_ShowString(68,0,"0",16);
    }

    OLED_ShowNum(34,3,TimeData.hour,2,16);
    OLED_ShowString(54,3,":",16);
    OLED_ShowNum(64,3,TimeData.minute,2,16);
    OLED_ShowString(84,3,":",16);
    OLED_ShowNum(94,3,TimeData.second,2,16);
    if(TimeData.minute<10)
    {
        OLED_ShowString(64,3,"0",16);
    }
    if(TimeData.second<10)
    {
        OLED_ShowString(94,3,"0",16);
    }
    if(TimeData.hour<10)
    {
        OLED_ShowString(34,3,"0",16);
    }
}

void RealTime_Display(void)
{
    OLED_ShowChinese(112,0,TimeData.week+13);

    OLED_ShowNum(94,3,TimeData.second,2,16);
    if(TimeData.second<10)
    {
        OLED_ShowString(94,3,"0",16);
    }

    if(TimeData.second==0)
    {
        OLED_ShowNum(0,0,TimeData.year,4,16);
        OLED_ShowString(32,0,"-",16);
        OLED_ShowNum(42,0,TimeData.month,2,16);
        OLED_ShowString(58,0,"-",16);
        OLED_ShowNum(68,0,TimeData.day,2,16);

        if(TimeData.month<10)
        {
            OLED_ShowString(42,0,"0",16);
        }
        if(TimeData.day<10)
        {
            OLED_ShowString(68,0,"0",16);
        }

        OLED_ShowNum(34,3,TimeData.hour,2,16);
        OLED_ShowString(54,3,":",16);
        OLED_ShowNum(64,3,TimeData.minute,2,16);
        OLED_ShowString(84,3,":",16);

        if(TimeData.minute<10)
        {
            OLED_ShowString(64,3,"0",16);
        }

        if(TimeData.hour<10)
        {
            OLED_ShowString(34,3,"0",16);
        }
    }
}

void Modify_RealTime_Display(void)
{
    OLED_ShowChinese(84,0,12);
    OLED_ShowChinese(98,0,13);
    OLED_ShowChinese(112,0,TimeData.week+13);

    OLED_ShowNum(94,3,TimeData.second,2,16);
    if(TimeData.second<10)
    {
        OLED_ShowString(94,3,"0",16);
    }

    OLED_ShowNum(0,0,TimeData.year,4,16);
    OLED_ShowString(32,0,"-",16);
    OLED_ShowNum(42,0,TimeData.month,2,16);
    OLED_ShowString(58,0,"-",16);
    OLED_ShowNum(68,0,TimeData.day,2,16);
    if(TimeData.month<10)
    {
        OLED_ShowString(42,0,"0",16);
    }
    if(TimeData.day<10)
    {
        OLED_ShowString(68,0,"0",16);
    }

    OLED_ShowNum(34,3,TimeData.hour,2,16);
    OLED_ShowString(54,3,":",16);
    OLED_ShowNum(64,3,TimeData.minute,2,16);
    OLED_ShowString(84,3,":",16);

    if(TimeData.minute<10)
    {
        OLED_ShowString(64,3,"0",16);
    }
    if(TimeData.hour<10)
    {
        OLED_ShowString(34,3,"0",16);
    }
}
