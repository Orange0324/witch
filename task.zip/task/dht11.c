#include "dht11.h"
#include "driver_timer.h"
#include "stm32f1xx_hal.h"

void DHT11_DelayUs(uint32_t nus)
{
  uint32_t i=0;
  for(i=0; i<nus*12; i++) __NOP();
}

void DHT11_DelayMs(uint32_t nms)
{
  HAL_Delay(nms);
}

// 设置数据引脚为输出
static void DHT11_SetOutput(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    GPIO_InitStruct.Pin = DHT11_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(DHT11_PORT, &GPIO_InitStruct);
}

// 设置数据引脚为输入
static void DHT11_SetInput(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    GPIO_InitStruct.Pin = DHT11_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(DHT11_PORT, &GPIO_InitStruct);
}

static int DHT11_PinRead(void)
{
    if (GPIO_PIN_SET == HAL_GPIO_ReadPin(DHT11_PORT, DHT11_PIN))
		return 1;
	else
		return 0;
}



// 初始化 DHT11
void DHT11_Init(void)
{
    DHT11_SetOutput();
		DHT11_Dout_1;
}

static void DHT11_Start(void)
{
	DHT11_Dout_0;
	mdelay(20);
	DHT11_SetInput();
}

static int DHT11_Wait_Ack(void)
{
	int timeout = 100;
	while (timeout--)
	{
		if (DHT11_PinRead() == 0)
			return 0; /* ok, DHT11 pulled low */
		udelay(1);
	}
	return -1; /* err, no ack */
}

static int DHT11_WaitFor_Val(int val, int timeout_us)
{
	while (timeout_us--)
	{
		if (DHT11_PinRead() == val)
			return 0; /* ok */
		udelay(1);
	}
	return -1; /* err */
}

// 读取一个字节
static uint8_t DHT11_ReadByte(void)
{
  int i;
	int data = 0;
	
	for (i = 0; i < 8; i++)
	{
		if (DHT11_WaitFor_Val(1, 1000))
		{
			//printf("dht11 wait for high data err!\n\r");
			return -1;
		}
		udelay(40);
		data <<= 1;
		if (DHT11_PinRead() == 1)
			data |= 1;
		
		if (DHT11_WaitFor_Val(0, 1000))
		{
			//printf("dht11 wait for low data err!\n\r");
			return -1;
		}
	}
	
	return data;
}

// 读取温湿度数据
int DHT11_Read(uint8_t *hum, uint8_t *temp)
{
	unsigned char hum_m, hum_n;
	unsigned char temp_m, temp_n;
	unsigned char check;	
	
	DHT11_Start();
	
	if (0 != DHT11_Wait_Ack())
	{
		//printf("dht11 not ack, err!\n\r");
		return -1;
	}

	if (0 != DHT11_WaitFor_Val(1, 1000))  /* 等待ACK变为高电平, 超时时间是1000us */
	{
		//printf("dht11 wait for ack high err!\n\r");
		return -1;
	}

	if (0 != DHT11_WaitFor_Val(0, 1000))  /* 数据阶段: 等待低电平, 超时时间是1000us */
	{
		//printf("dht11 wait for data low err!\n\r");
		return -1;
	}

	hum_m  = DHT11_ReadByte();
	hum_n  = DHT11_ReadByte();
	temp_m = DHT11_ReadByte();
	temp_n = DHT11_ReadByte();
	check  = DHT11_ReadByte();

	DHT11_SetOutput();
	DHT11_Dout_1;

	if (hum_m + hum_n + temp_m + temp_n == check)
	{
		*hum  = hum_m;
		*temp = temp_m;
		return 0;
	}
	else
	{
		//printf("dht11 checksum err!\n\r");
		return -1;
	}

}
