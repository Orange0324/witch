#ifndef __DS1302_H
#define __DS1302_H

#include "main.h"

/**
 * @brief  DS1302实时时钟芯片引脚定义
 * @note   使用CubeMX生成的引脚配置
 */
#define DS1302_CE_PORT   GPIOA           // CE引脚端口
#define DS1302_CE_PIN    DS1302_CE_Pin   // CE引脚（芯片使能）

#define DS1302_SCLK_PORT GPIOA           // SCLK引脚端口
#define DS1302_SCLK_PIN  DS1302_SCLK_Pin // SCLK引脚（串行时钟）

#define DS1302_DATA_PORT GPIOA           // DATA引脚端口
#define DS1302_DATA_PIN  DS1302_DATA_Pin // DATA引脚（串行数据）

/**
 * @brief  实时时间显示标志位
 * @note   用于控制时间显示更新
 */
extern uint8_t RealTime_Display_flag;

/**
 * @brief  GPIO操作宏定义
 * @note   封装HAL库GPIO操作，简化代码
 */
#define CE_L()  HAL_GPIO_WritePin(DS1302_CE_PORT, DS1302_CE_PIN, GPIO_PIN_RESET)   // CE引脚拉低（禁用芯片）
#define CE_H()  HAL_GPIO_WritePin(DS1302_CE_PORT, DS1302_CE_PIN, GPIO_PIN_SET)     // CE引脚拉高（使能芯片）
#define SCLK_L() HAL_GPIO_WritePin(DS1302_SCLK_PORT, DS1302_SCLK_PIN, GPIO_PIN_RESET) // SCLK引脚拉低
#define SCLK_H() HAL_GPIO_WritePin(DS1302_SCLK_PORT, DS1302_SCLK_PIN, GPIO_PIN_SET)   // SCLK引脚拉高
#define DATA_L() HAL_GPIO_WritePin(DS1302_DATA_PORT, DS1302_DATA_PIN, GPIO_PIN_RESET) // DATA引脚拉低（写0）
#define DATA_H() HAL_GPIO_WritePin(DS1302_DATA_PORT, DS1302_DATA_PIN, GPIO_PIN_SET)   // DATA引脚拉高（写1）
#define DATA_READ() HAL_GPIO_ReadPin(DS1302_DATA_PORT, DS1302_DATA_PIN)               // 读取DATA引脚状态

/**
 * @brief  时间数据结构
 * @note   存储年、月、日、时、分、秒、星期信息
 */
struct TIMEData
{
    uint16_t year;    // 年份（完整年份，如2024）
    uint8_t  month;   // 月份（1-12）
    uint8_t  day;     // 日期（1-31）
    uint8_t  hour;    // 小时（0-23）
    uint8_t  minute;  // 分钟（0-59）
    uint8_t  second;  // 秒（0-59）
    uint8_t  week;    // 星期（1-7，1表示星期一）
};

/**
 * @brief  全局时间数据变量
 * @note   存储当前时间信息，供各任务访问
 */
extern struct TIMEData TimeData;

/**
 * @brief  时间缓冲区
 * @note   用于临时存储从DS1302读取的BCD格式数据
 */
extern uint8_t time_buf[8];

/**
 * @brief  DS1302初始化函数
 * @note   配置DS1302工作模式，启动时钟
 * @retval None
 */
void DS1302_Init(void);

/**
 * @brief  将时间写入DS1302
 * @note   将TimeData中的时间写入DS1302芯片
 * @retval None
 */
void DS1302_WriteTime(void);

/**
 * @brief  从DS1302读取时间（BCD格式）
 * @note   读取原始BCD格式数据到time_buf
 * @retval None
 */
void DS1302_ReadTime(void);

/**
 * @brief  从DS1302读取时间并转换为十进制格式
 * @note   读取时间并转换后存入TimeData
 * @retval None
 */
void DS1302_ReadRealTime(void);

/**
 * @brief  实时时间显示初始化
 * @note   初始化时间显示相关资源
 * @retval None
 */
void RealTime_Display_Init(void);

/**
 * @brief  实时时间显示
 * @note   显示当前时间并实时刷新
 * @retval None
 */
void RealTime_Display(void);

/**
 * @brief  修改时间后刷新显示
 * @note   修改时间后调用此函数刷新显示一次
 * @retval None
 */
void Modify_RealTime_Display(void);

#endif
