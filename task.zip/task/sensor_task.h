#ifndef __SENSOR_TASK_H
#define __SENSOR_TASK_H

#include "main.h"
#include "FreeRTOS.h"
#include "task.h"

// 传感器数据结构体
typedef struct {
    uint8_t temperature;
    uint8_t humidity;
} SensorData_t;

extern SensorData_t g_SensorData;

// 传感器任务创建函数
void Sensor_Task_Create(void);

// 获取传感器数据
void Sensor_GetData(SensorData_t *data);

#endif
