#include "bsp_oled.h"
#include "font.h"
#include "FreeRTOS.h"
#include "task.h"

/**
 * @brief  简单的空循环延时函数
 * @note   不依赖任何外设或中断，适用于FreeRTOS环境
 * @param  ms: 延时毫秒数
 * @retval None
 */
static void OLED_Delay_ms(uint32_t ms)
{
    volatile uint32_t i, j;
    for(i = 0; i < ms; i++)
    {
        for(j = 0; j < 200; j++)  // 约1ms @72MHz
        {
            __NOP(); __NOP(); __NOP(); __NOP();
            __NOP(); __NOP(); __NOP(); __NOP();
        }
    }
}

/**
 * @brief  OLED显存数组
 * @note   128x64分辨率，每个字节代表8个像素（一页）
 *         共8页，每页128字节
 */
unsigned char OLED_GRAM[144][8];

/**
 * @brief  幂运算函数
 * @param  m: 底数
 * @param  n: 指数
 * @retval m^n 的结果
 */
static u32 oled_pow(u8 m, u8 n)
{
	u32 result = 1;
	while(n--) result *= m;
	return result;
}

/**
 * @brief  I2C起始信号
 * @note   时序：SCL=1时，SDA从1变为0
 * @retval None
 */
static void IIC_Start(void)
{
	OLED_SCLK_Set();  // SCL = 1
	OLED_SDIN_Set();  // SDA = 1
	OLED_SDIN_Clr();  // SDA = 0 (起始条件)
	OLED_SCLK_Clr();  // SCL = 0
}

/**
 * @brief  I2C停止信号
 * @note   时序：SCL=1时，SDA从0变为1
 * @retval None
 */
static void IIC_Stop(void)
{
	OLED_SCLK_Set();  // SCL = 1
	OLED_SDIN_Clr();  // SDA = 0
	OLED_SDIN_Set();  // SDA = 1 (停止条件)
}

/**
 * @brief  I2C等待应答
 * @note   从设备在第9个时钟周期拉低SDA作为应答
 * @retval None
 */
static void IIC_Wait_Ack(void)
{
	OLED_SCLK_Set();  // 第9个时钟脉冲
	OLED_SCLK_Clr();  // 完成一个时钟周期
}

/**
 * @brief  I2C写入一个字节
 * @param  IIC_Byte: 要写入的字节数据
 * @retval None
 */
static void Write_IIC_Byte(unsigned char IIC_Byte)
{
	unsigned char i;
	unsigned char m, da;
	da = IIC_Byte;
	OLED_SCLK_Clr();  // 拉低时钟开始传输
	for(i = 0; i < 8; i++)
	{
		m = da;
		m = m & 0x80;  // 取最高位
		if(m == 0x80)
			OLED_SDIN_Set();  // 写1
		else
			OLED_SDIN_Clr();  // 写0
		da = da << 1;  // 左移一位
		OLED_SCLK_Set();  // 时钟上升沿锁存数据
		OLED_SCLK_Clr();  // 时钟下降沿准备下一位
	}
}

/**
 * @brief  判断FreeRTOS调度器是否正在运行
 * @retval 1-运行中，0-未运行
 */
static inline uint8_t IsSchedulerRunning(void)
{
	return (xTaskGetSchedulerState() == taskSCHEDULER_RUNNING);
}

/**
 * @brief  向OLED写入命令
 * @note   使用临界区保护I2C时序，防止任务切换干扰
 * @param  IIC_Command: 要写入的命令字节
 * @retval None
 */
static void Write_IIC_Command(unsigned char IIC_Command)
{
	// 进入临界区保护I2C通信时序
	if(IsSchedulerRunning())
	{
		taskENTER_CRITICAL();
	}
	
	IIC_Start();               // 发送起始信号
	Write_IIC_Byte(0x78);     // OLED设备地址(0x3C << 1 = 0x78)
	IIC_Wait_Ack();           // 等待应答
	Write_IIC_Byte(0x00);     // 控制字节：写命令(Co=0,D/C#=0)
	IIC_Wait_Ack();           // 等待应答
	Write_IIC_Byte(IIC_Command); // 写入命令数据
	IIC_Wait_Ack();           // 等待应答
	IIC_Stop();               // 发送停止信号
	
	// 退出临界区
	if(IsSchedulerRunning())
	{
		taskEXIT_CRITICAL();
	}
}

/**
 * @brief  向OLED写入数据
 * @note   使用临界区保护I2C时序，防止任务切换干扰
 * @param  IIC_Data: 要写入的数据字节
 * @retval None
 */
static void Write_IIC_Data(unsigned char IIC_Data)
{
	// 进入临界区保护I2C通信时序
	if(IsSchedulerRunning())
	{
		taskENTER_CRITICAL();
	}
	
	IIC_Start();               // 发送起始信号
	Write_IIC_Byte(0x78);     // OLED设备地址(0x3C << 1 = 0x78)
	IIC_Wait_Ack();           // 等待应答
	Write_IIC_Byte(0x40);     // 控制字节：写数据(Co=0,D/C#=1)
	IIC_Wait_Ack();           // 等待应答
	Write_IIC_Byte(IIC_Data); // 写入显示数据
	IIC_Wait_Ack();           // 等待应答
	IIC_Stop();               // 发送停止信号
	
	// 退出临界区
	if(IsSchedulerRunning())
	{
		taskEXIT_CRITICAL();
	}
}

/**
 * @brief  OLED写入一个字节
 * @param  dat: 要写入的数据
 * @param  cmd: 0-命令, 1-数据
 * @retval None
 */
void OLED_WR_Byte(u8 dat, u8 cmd)
{
    if(cmd)
        Write_IIC_Data(dat);
    else
        Write_IIC_Command(dat);
}

/**
 * @brief  设置OLED显示位置
 * @param  x: 列坐标(0-127)
 * @param  y: 页坐标(0-7)
 * @retval None
 */
void OLED_Set_Pos(unsigned char x, unsigned char y)
{
    OLED_WR_Byte(0xb0 + y, OLED_CMD);                    // 设置页地址
    OLED_WR_Byte(((x & 0xf0) >> 4) | 0x10, OLED_CMD);   // 设置列地址高4位
    OLED_WR_Byte((x & 0x0f), OLED_CMD);                  // 设置列地址低4位
}

/**
 * @brief  开启OLED显示
 * @retval None
 */
void OLED_Display_On(void)
{
    OLED_WR_Byte(0X8D, OLED_CMD);  // 电荷泵设置
    OLED_WR_Byte(0X14, OLED_CMD);  // 开启电荷泵
    OLED_WR_Byte(0XAF, OLED_CMD);  // 开启显示
}

/**
 * @brief  关闭OLED显示
 * @retval None
 */
void OLED_Display_Off(void)
{
    OLED_WR_Byte(0X8D, OLED_CMD);  // 电荷泵设置
    OLED_WR_Byte(0X10, OLED_CMD);  // 关闭电荷泵
    OLED_WR_Byte(0XAE, OLED_CMD);  // 关闭显示
}

/**
 * @brief  清屏函数
 * @note   将所有显示内容填充为0
 * @retval None
 */
void OLED_Clear(void)
{
    u8 i, n;
    for(i = 0; i < 8; i++)           // 遍历8页
    {
        OLED_WR_Byte(0xb0 + i, OLED_CMD);  // 设置页地址
        OLED_WR_Byte(0x00, OLED_CMD);     // 列地址低4位
        OLED_WR_Byte(0x10, OLED_CMD);     // 列地址高4位
        for(n = 0; n < 128; n++)         // 每页128列
            OLED_WR_Byte(0, OLED_DATA);   // 写入0
    }
}

/**
 * @brief  显示单个字符
 * @param  x: 起始列坐标
 * @param  y: 起始页坐标
 * @param  chr: 要显示的字符
 * @param  Char_Size: 字符大小(8x16或6x8)
 * @retval None
 */
void OLED_ShowChar(u8 x, u8 y, u8 chr, u8 Char_Size)
{
    unsigned char c = 0, i = 0;
    c = chr - ' ';  // 计算字符在字库中的偏移(空格为第一个字符)
    
    // 越界处理
    if(x > Max_Column - 1) { x = 0; y = y + 2; }
    
    if(Char_Size == 16)  // 8x16字体
    {
        OLED_Set_Pos(x, y);           // 设置位置
        for(i = 0; i < 8; i++)        // 显示上半部分(8字节)
            OLED_WR_Byte(F8X16[c * 16 + i], OLED_DATA);
        OLED_Set_Pos(x, y + 1);       // 切换到下一页
        for(i = 0; i < 8; i++)        // 显示下半部分(8字节)
            OLED_WR_Byte(F8X16[c * 16 + i + 8], OLED_DATA);
    }
    else  // 6x8字体
    {
        OLED_Set_Pos(x, y);           // 设置位置
        for(i = 0; i < 6; i++)        // 显示6字节
            OLED_WR_Byte(F6x8[c][i], OLED_DATA);
    }
}

/**
 * @brief  颜色反转
 * @param  i: 0-正常显示, 1-反转显示
 * @retval None
 */
void OLED_ColorTurn(u8 i)
{
    if(i == 0)
        OLED_WR_Byte(0xA6, OLED_CMD);  // 正常显示
    if(i == 1)
        OLED_WR_Byte(0xA7, OLED_CMD);  // 反显模式
}

/**
 * @brief  屏幕翻转
 * @param  i: 0-正常方向, 1-翻转180度
 * @retval None
 */
void OLED_DisplayTurn(u8 i)
{
    if(i == 0)
    {
        OLED_WR_Byte(0xC8, OLED_CMD);  // COM扫描方向反转
        OLED_WR_Byte(0xA1, OLED_CMD);  // 段重映射反转
    }
    if(i == 1)
    {
        OLED_WR_Byte(0xC0, OLED_CMD);  // COM扫描方向正常
        OLED_WR_Byte(0xA0, OLED_CMD);  // 段重映射正常
    }
}

/**
 * @brief  画点
 * @param  x: 列坐标(0-127)
 * @param  y: 行坐标(0-63)
 * @retval None
 */
void OLED_DrawPoint(u8 x, u8 y)
{
    u8 i, m, n;
    i = y / 8;      // 计算所在页
    m = y % 8;      // 计算在页内的位位置
    n = 1 << m;     // 创建位掩码
    OLED_GRAM[x][i] |= n;  // 在显存中设置该位
}

/**
 * @brief  显示数字
 * @param  x: 起始列坐标
 * @param  y: 起始页坐标
 * @param  num: 要显示的数字
 * @param  len: 显示位数
 * @param  size2: 字符大小
 * @retval None
 */
void OLED_ShowNum(u8 x, u8 y, u32 num, u8 len, u8 size2)
{
    u8 t, temp;
    u8 enshow = 0;  // 有效数字标志
    for(t = 0; t < len; t++)
    {
        temp = (num / oled_pow(10, len - t - 1)) % 10;  // 提取每一位数字
        
        // 前导零处理：跳过前导零，直到遇到有效数字
        if(enshow == 0 && t < (len - 1))
        {
            if(temp == 0)
            {
                OLED_ShowChar(x + (size2 / 2) * t, y, ' ', size2);  // 显示空格
                continue;
            }
            else
                enshow = 1;  // 遇到有效数字，开始显示
        }
        OLED_ShowChar(x + (size2 / 2) * t, y, temp + '0', size2);  // 显示数字
    }
}

/**
 * @brief  显示字符串
 * @param  x: 起始列坐标
 * @param  y: 起始页坐标
 * @param  chr: 字符串指针
 * @param  Char_Size: 字符大小
 * @retval None
 */
void OLED_ShowString(u8 x, u8 y, const char *chr, u8 Char_Size)
{
    unsigned char j = 0;
    while(chr[j] != '\0')  // 遍历字符串直到结束
    {
        OLED_ShowChar(x, y, chr[j], Char_Size);  // 显示单个字符
        x += 8;  // 移动到下一个字符位置
        if(x > 120) { x = 0; y += 2; }  // 换行处理
        j++;
    }
}

/**
 * @brief  显示中文汉字
 * @note   使用HZK16字库，每个汉字占用32字节(16x16点阵)
 * @param  x: 起始列坐标
 * @param  y: 起始页坐标
 * @param  no: 汉字在字库中的索引
 * @retval None
 */
void OLED_ShowChinese(u8 x, u8 y, u8 no)
{
    u8 t;
    OLED_Set_Pos(x, y);
    for(t = 0; t < 16; t++)
    {
        OLED_WR_Byte(Hzk1[2 * no][t], OLED_DATA);  // 显示上半部分(16字节)
    }
    OLED_Set_Pos(x, y + 1);
    for(t = 0; t < 16; t++)
    {
        OLED_WR_Byte(Hzk1[2 * no + 1][t], OLED_DATA);  // 显示下半部分(16字节)
    }
}

/**
 * @brief  清除一个点
 * @param  x: 列坐标(0-127)
 * @param  y: 行坐标(0-63)
 * @retval None
 */
void OLED_ClearPoint(u8 x, u8 y)
{
    u8 i, m, n;
    i = y / 8;      // 计算所在页
    m = y % 8;      // 计算在页内的位位置
    n = 1 << m;     // 创建位掩码
    OLED_GRAM[x][i] = ~OLED_GRAM[x][i];  // 取反
    OLED_GRAM[x][i] |= n;                 // 置位该位
    OLED_GRAM[x][i] = ~OLED_GRAM[x][i];  // 再次取反，实现清零
}

/**
 * @brief  显示BMP图片
 * @param  x0: 起始列坐标
 * @param  y0: 起始页坐标
 * @param  x1: 结束列坐标
 * @param  y1: 结束页坐标
 * @param  BMP: BMP图片数据指针
 * @retval None
 */
void OLED_DrawBMP(unsigned char x0, unsigned char y0, unsigned char x1, unsigned char y1, const unsigned char BMP[])
{
    unsigned int j = 0;
    unsigned char x, y;
    
    // 计算需要显示的页数
    if(y1 % 8 == 0) y = y1 / 8;
    else y = y1 / 8 + 1;
    
    for(y = y0; y < y1; y++)
    {
        OLED_Set_Pos(x0, y);           // 设置页地址
        for(x = x0; x < x1; x++)
        {
            OLED_WR_Byte(BMP[j++], OLED_DATA);  // 写入图片数据
        }
    }
}

/**
 * @brief  刷新显存到OLED
 * @note   将OLED_GRAM中的内容写入OLED显示
 * @retval None
 */
void OLED_Refresh(void)
{
    u8 i, n;
    for(i = 0; i < 8; i++)           // 遍历8页
    {
        OLED_WR_Byte(0xb0 + i, OLED_CMD);  // 设置页地址
        OLED_WR_Byte(0x00, OLED_CMD);     // 列地址低4位
        OLED_WR_Byte(0x10, OLED_CMD);     // 列地址高4位
        for(n = 0; n < 128; n++)         // 每页128列
            OLED_WR_Byte(OLED_GRAM[n][i], OLED_DATA);  // 写入显存数据
    }
}

/**
 * @brief  填充区域
 * @param  x1: 起始列坐标
 * @param  y1: 起始行坐标
 * @param  x2: 结束列坐标
 * @param  y2: 结束行坐标
 * @param  dot: 填充值(0或1)
 * @retval None
 */
void OLED_Fill(u8 x1, u8 y1, u8 x2, u8 y2, u8 dot)
{
    u8 x, y;
    for(x = x1; x <= x2; x++)
    {
        for(y = y1; y <= y2; y++)
        {
            OLED_DrawPoint(x, y);  // 绘制每个点
        }
    }
    OLED_Refresh();  // 刷新显示
}

/**
 * @brief  OLED初始化函数
 * @note   按照SSD1306手册的初始化序列配置OLED
 * @retval None
 */
void OLED_Init(void)
{
    // GPIO已由CubeMX初始化，这里确保初始状态正确
    HAL_GPIO_WritePin(OLED_SCLK_PORT, OLED_SCLK_PIN, GPIO_PIN_SET);
    HAL_GPIO_WritePin(OLED_SDIN_PORT, OLED_SDIN_PIN, GPIO_PIN_SET);
    
    OLED_Delay_ms(100);  // 等待OLED电源稳定
    
    // 关闭显示
    OLED_WR_Byte(0xAE, OLED_CMD);
    
    // 设置列地址
    OLED_WR_Byte(0x00, OLED_CMD);  // 低列地址
    OLED_WR_Byte(0x10, OLED_CMD);  // 高列地址
    
    // 设置起始行地址
    OLED_WR_Byte(0x40, OLED_CMD);
    
    // 设置对比度
    OLED_WR_Byte(0x81, OLED_CMD);
    OLED_WR_Byte(0xCF, OLED_CMD);  // 对比度值(0x00-0xFF)
    
    // 段重映射(水平翻转)
    OLED_WR_Byte(0xA1, OLED_CMD);
    
    // COM扫描方向(垂直翻转)
    OLED_WR_Byte(0xC8, OLED_CMD);
    
    // 正常显示模式
    OLED_WR_Byte(0xA6, OLED_CMD);
    
    // 设置多路复用率
    OLED_WR_Byte(0xA8, OLED_CMD);
    OLED_WR_Byte(0x3f, OLED_CMD);  // 1/64 duty
    
    // 设置显示偏移
    OLED_WR_Byte(0xD3, OLED_CMD);
    OLED_WR_Byte(0x00, OLED_CMD);  // 无偏移
    
    // 设置时钟分频
    OLED_WR_Byte(0xD5, OLED_CMD);
    OLED_WR_Byte(0x80, OLED_CMD);  // 默认分频
    
    // 设置预充电周期
    OLED_WR_Byte(0xD9, OLED_CMD);
    OLED_WR_Byte(0xF1, OLED_CMD);
    
    // COM硬件配置
    OLED_WR_Byte(0xDA, OLED_CMD);
    OLED_WR_Byte(0x12, OLED_CMD);
    
    // VCOMH设置
    OLED_WR_Byte(0xDB, OLED_CMD);
    OLED_WR_Byte(0x40, OLED_CMD);
    
    // 设置地址模式
    OLED_WR_Byte(0x20, OLED_CMD);
    OLED_WR_Byte(0x02, OLED_CMD);  // 页面地址模式
    
    // 开启电荷泵
    OLED_WR_Byte(0x8D, OLED_CMD);
    OLED_WR_Byte(0x14, OLED_CMD);
    
    // 全屏显示关闭(显示显存内容)
    OLED_WR_Byte(0xA4, OLED_CMD);
    
    // 正常显示
    OLED_WR_Byte(0xA6, OLED_CMD);
    
    // 开启显示
    OLED_WR_Byte(0xAF, OLED_CMD);
    
    // 清屏
    OLED_Clear();
}
