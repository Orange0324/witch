#ifndef __OLED_H
#define __OLED_H

#include "main.h"



// �������Ͷ���
#ifndef u8
#define u8  uint8_t
#endif
#ifndef u16
#define u16 uint16_t
#endif
#ifndef u32
#define u32 uint32_t
#endif

// OLED ��������
#define OLED_MODE 0
#define SIZE 8
#define XLevelL     0x00
#define XLevelH     0x10
#define Max_Column  128
#define Max_Row     64
#define Brightness  0xFF
#define X_WIDTH     128
#define Y_WIDTH     64

// OLED IIC ����
#define OLED_SCLK_PORT  GPIOB
#define OLED_SCLK_PIN   OLED_ACL_Pin
#define OLED_SDIN_PORT  GPIOB
#define OLED_SDIN_PIN   OLED_SDA_Pin

#define OLED_SCLK_Clr() HAL_GPIO_WritePin(OLED_SCLK_PORT, OLED_SCLK_PIN, GPIO_PIN_RESET)
#define OLED_SCLK_Set() HAL_GPIO_WritePin(OLED_SCLK_PORT, OLED_SCLK_PIN, GPIO_PIN_SET)
#define OLED_SDIN_Clr() HAL_GPIO_WritePin(OLED_SDIN_PORT, OLED_SDIN_PIN, GPIO_PIN_RESET)
#define OLED_SDIN_Set() HAL_GPIO_WritePin(OLED_SDIN_PORT, OLED_SDIN_PIN, GPIO_PIN_SET)

#define OLED_CMD  0
#define OLED_DATA 1

// OLED写字节函数 - 供外部调用的底层函数
void OLED_WR_Byte(u8 dat, u8 cmd);
void OLED_Display_On(void);
void OLED_Display_Off(void);
void OLED_Init(void);
void OLED_Clear(void);
void OLED_Fill(u8 x1, u8 y1, u8 x2, u8 y2, u8 dot);
void OLED_ShowChar(u8 x, u8 y, u8 chr, u8 Char_Size);
void OLED_ShowNum(u8 x, u8 y, u32 num, u8 len, u8 size);
void OLED_ShowString(u8 x, u8 y, const char *p, u8 Char_Size);
void OLED_Set_Pos(unsigned char x, unsigned char y);
void OLED_DrawBMP(unsigned char x0, unsigned char y0, unsigned char x1, unsigned char y1, const unsigned char BMP[]);
void OLED_ClearPoint(u8 x, u8 y);
void OLED_DrawPoint(u8 x, u8 y);
void OLED_ShowChinese(u8 x, u8 y, u8 no);
void OLED_Refresh(void);
void OLED_ColorTurn(u8 i);
void OLED_DisplayTurn(u8 i);

#endif
