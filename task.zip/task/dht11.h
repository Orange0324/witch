#ifndef __DHT11_H
#define __DHT11_H

#include "main.h"

#define DHT11_PORT  GPIOA
#define DHT11_PIN   DHT11_DATA_Pin

#define      DHT11_Dout_0	                            HAL_GPIO_WritePin(DHT11_PORT, DHT11_PIN, GPIO_PIN_RESET)
#define      DHT11_Dout_1	                            HAL_GPIO_WritePin(DHT11_PORT, DHT11_PIN, GPIO_PIN_SET)
#define      DHT11_Dout_IN()	                        HAL_GPIO_ReadPin(DHT11_PORT, DHT11_PIN)

typedef struct
{
    uint8_t humi_int;
    uint8_t humi_deci;
    uint8_t temp_int;
    uint8_t temp_deci;
    uint8_t check_sum;
} DHT11_Data_TypeDef;

void DHT11_Init(void);
uint8_t DHT11_Read_Data(DHT11_Data_TypeDef *DHT11_Data);
int DHT11_Read(uint8_t *hum, uint8_t *temp);

#endif
